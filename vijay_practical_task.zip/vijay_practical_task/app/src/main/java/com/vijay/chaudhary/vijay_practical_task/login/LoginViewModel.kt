package com.vijay.chaudhary.vijay_practical_task.login

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.me.khatavahi.utilities.isValidEmail
import com.me.khatavahi.utilities.isValidPassword

class LoginViewModel(application: Application) : AndroidViewModel(application) {
    private val context = getApplication<Application>().applicationContext

    var isLogin: MutableLiveData<Boolean>? = MutableLiveData()

    var btnLoginSelected: MutableLiveData<Boolean>? = MutableLiveData(false)
    val email: MutableLiveData<String>? = MutableLiveData<String>("")
    val password: MutableLiveData<String>? = MutableLiveData("")

    private val emailObserver = Observer<String> { _email ->
        btnLoginSelected?.value =
            emailCriteria(_email)
                    && passwordCriteria(password?.value.toString())
    }

    private val passwordObserver = Observer<String> { _password ->
        btnLoginSelected?.value =
            emailCriteria(email?.value.toString()) && passwordCriteria(_password)
    }

    init {
        email?.observeForever(emailObserver)
        password?.observeForever(passwordObserver)
    }

    private fun emailCriteria(email: String): Boolean = email.isValidEmail()
    private fun passwordCriteria(password: String): Boolean = password.isValidPassword()


    fun login() {
        isLogin?.value =
            (email?.value.toString() == "hello@yopmail.com" && password?.value.toString() == "Password@123")
    }

    override fun onCleared() {
        email?.removeObserver(emailObserver)
        password?.removeObserver(passwordObserver)
    }
}