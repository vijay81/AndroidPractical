package com.vijay.chaudhary.vijay_practical_task.home_detail

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.vijay.chaudhary.vijay_practical_task.R
import com.vijay.chaudhary.vijay_practical_task.databinding.ActivityHomeDetailBinding
import com.vijay.chaudhary.vijay_practical_task.databinding.ActivityMainBinding
import com.vijay.chaudhary.vijay_practical_task.login.LoginActivity
import com.vijay.chaudhary.vijay_practical_task.utilities.SharedPref

class HomeDetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHomeDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_home_detail)
        binding.lifecycleOwner = this

        supportActionBar?.title = "Home Detail"

        Glide.with(baseContext)
            .load(intent.getStringExtra("url"))
            .error(android.R.drawable.ic_dialog_alert)
            .into(binding.imgDetail)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_home_detail, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here.
        val id = item.itemId

        if (id == R.id.action_logout) {
            SharedPref.getInstance(baseContext).clearAllSharedPref()
            finish()
            val intent = Intent(Intent(this, LoginActivity::class.java))
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            return true
        }

        return super.onOptionsItemSelected(item)

    }
}