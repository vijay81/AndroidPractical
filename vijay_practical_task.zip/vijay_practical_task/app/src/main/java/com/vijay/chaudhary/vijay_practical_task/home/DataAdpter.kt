package com.vijay.chaudhary.vijay_practical_task.home

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.vijay.chaudhary.vijay_practical_task.R

class DataAdpter(
    private var dataList: List<Home>,
    private val context: Context,
    private val listener: (Home) -> Unit
) :

    RecyclerView.Adapter<DataAdpter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(context).inflate(R.layout.list_home, parent, false))
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindItems(dataList[position])
    }


    inner class ViewHolder(itemLayoutView: View) : RecyclerView.ViewHolder(itemLayoutView) {
        var titleTextView: TextView = itemLayoutView.findViewById(R.id.title)
        var thumb: ImageView = itemLayoutView.findViewById(R.id.thumbnail)
        fun bindItems(home: Home) = with(itemView) {
            titleTextView.text = home.title
            Glide.with(context)
                .load(home.thumbnailUrl)
                .error(android.R.drawable.ic_dialog_alert)
                .into(thumb)
            setOnClickListener { listener(home) }
        }
    }

}