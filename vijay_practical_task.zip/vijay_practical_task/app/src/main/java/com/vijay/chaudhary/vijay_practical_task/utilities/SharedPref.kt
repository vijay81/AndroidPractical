package com.vijay.chaudhary.vijay_practical_task.utilities

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences

class SharedPref(mContext: Context) {
    private val pref: SharedPreferences
    private val editor:SharedPreferences.Editor
    private val package_name:String = mContext.applicationContext.packageName

    init{
        pref = mContext.getSharedPreferences(package_name, Context.MODE_PRIVATE)
        editor = pref.edit()
    }
    fun putIntPref(key: String, value: Int) {
        editor.putInt(package_name + key, value)
        editor.commit()
    }
    fun getIntPref(key: String):Int {
        return pref.getInt(package_name + key, 0)
    }

    fun clearAllSharedPref() {
        editor.clear()
        editor.commit()
    }

    companion object {
        @SuppressLint("CommitPrefEdits")
        fun getInstance(mContext: Context):SharedPref {
            return SharedPref(mContext)
        }
        val KEY_LOGIN= "login"
    }
}