package com.vijay.chaudhary.vijay_practical_task.login

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.google.android.material.snackbar.Snackbar
import com.vijay.chaudhary.vijay_practical_task.home.MainActivity
import com.vijay.chaudhary.vijay_practical_task.R
import com.vijay.chaudhary.vijay_practical_task.databinding.ActivityLoginBinding
import com.vijay.chaudhary.vijay_practical_task.utilities.SharedPref

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private val viewModel: LoginViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_login)
        binding.viewmodel = viewModel
        binding.lifecycleOwner = this

        viewModel.isLogin?.observe(this, Observer { isLogin ->
            when (isLogin) {
                true -> {
                    finish()
                    SharedPref.getInstance(baseContext).putIntPref(SharedPref.KEY_LOGIN,1)
                    startActivity(Intent(this, MainActivity::class.java))
                }
                false -> Snackbar.make(
                    findViewById(android.R.id.content),
                    R.string.error_invalid_credentials,
                    Snackbar.LENGTH_SHORT
                )
                    .show()
            }
        })
    }
}