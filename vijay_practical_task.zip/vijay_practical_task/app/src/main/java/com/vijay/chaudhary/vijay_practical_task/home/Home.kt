package com.vijay.chaudhary.vijay_practical_task.home

data class Home (
    val albumId: Int,
    val id: Int,
    val title: String?,
    val url: String?,
    val thumbnailUrl: String?,
)