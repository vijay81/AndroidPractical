package com.vijay.chaudhary.vijay_practical_task.home

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.vijay.chaudhary.vijay_practical_task.R
import com.vijay.chaudhary.vijay_practical_task.databinding.ActivityMainBinding
import com.vijay.chaudhary.vijay_practical_task.home_detail.HomeDetailActivity
import com.vijay.chaudhary.vijay_practical_task.login.LoginActivity
import com.vijay.chaudhary.vijay_practical_task.network.ServiceBuilder
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private val TAG: String = "MainActivity"
    private lateinit var binding: ActivityMainBinding

    lateinit var progerssProgressDialog: ProgressDialog
    var dataList = ArrayList<Home>()
    lateinit var recyclerView: RecyclerView
    lateinit var adapter: DataAdpter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        binding.lifecycleOwner = this

        supportActionBar?.title = "Home"

        recyclerView = binding.recycler
        recyclerView.adapter = DataAdpter(dataList, this) { home ->
            val intent: Intent = Intent(this, HomeDetailActivity::class.java)
            intent.putExtra("url", home.url)
            startActivity(intent)
        }
        recyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)

        progerssProgressDialog = ProgressDialog(this)
        progerssProgressDialog.setTitle("Loading")
        progerssProgressDialog.setCancelable(false)
        progerssProgressDialog.show()
        getData()

    }

    private fun getData() {
        val call: Call<List<Home>> = ServiceBuilder.getClient.getData()
        call.enqueue(object : Callback<List<Home>> {

            override fun onResponse(call: Call<List<Home>>?, response: Response<List<Home>>?) {
                progerssProgressDialog.dismiss()
                dataList.addAll(response?.body()!!)
                recyclerView.adapter?.notifyDataSetChanged()
            }

            override fun onFailure(call: Call<List<Home>>?, t: Throwable?) {
                progerssProgressDialog.dismiss()
            }

        })
    }
}