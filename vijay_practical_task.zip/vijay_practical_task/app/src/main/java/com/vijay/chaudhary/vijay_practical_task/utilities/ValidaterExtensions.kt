package com.me.khatavahi.utilities

import android.util.Log
import android.util.Patterns
import android.widget.CheckBox
import android.widget.EditText
import androidx.core.widget.doAfterTextChanged

fun EditText.validate(message: String, validatorFun: (String) -> Boolean) {
    this.doAfterTextChanged {
        this.error = if (validatorFun(it.toString().trim())) null else message
    }
    this.error = if (validatorFun(this.text.toString().trim())) null else message
}

fun String.isValidEmail(): Boolean =
    this.isNotEmpty() && Patterns.EMAIL_ADDRESS.matcher(this).matches()

fun String.isValidMobile(): Boolean =
    this.isNotEmpty() && this.length == 10

fun String.isValidPassword(): Boolean =
    this.isNotEmpty() && this.length >= 8 && this.length <= 14

fun String.isValidConfirmPassword(password: String): Boolean =
    this.isNotEmpty() && this.equals(password, true)

