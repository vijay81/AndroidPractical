package com.vijay.chaudhary.vijay_practical_task.home

interface RecyclerAdapterListener {
    fun onCardSelected(home: Home)
}