package com.vijay.chaudhary.vijay_practical_task.network

import com.vijay.chaudhary.vijay_practical_task.home.Home
import retrofit2.Call
import retrofit2.http.GET

interface ApiService {
    @GET("photos")
    fun getData(): Call<List<Home>>
}